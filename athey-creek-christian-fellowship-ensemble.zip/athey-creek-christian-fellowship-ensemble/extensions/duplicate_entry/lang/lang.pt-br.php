<?php

	$about = array(
		'name' => 'Portuguese (Brazil)',
		'author' => array(
			'name' => 'Marcio Toledo',
			'email' => 'mt@marciotoledo.com',
			'website' => 'http://marciotoledo.com'
		),
		'release-date' => '2011-03-09'
	);

	/*
	 * EXTENSION: Duplicate Entry
	 * Add 'Save as New' button on edit entry
	 */

	$dictionary = array(
	
		'Save as New' => 
		'Salvar como Novo',

	);
