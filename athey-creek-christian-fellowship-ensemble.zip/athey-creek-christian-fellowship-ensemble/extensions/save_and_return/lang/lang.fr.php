<?php

	$about = array(
		'name' => 'Français',
		'author' => array(
			'name' => 'Solutions Nitriques',
			'email' => 'nico (at) nitriques.com',
			'website' => 'http://www.nitriques.com/'
		),
		'release-date' => '2011-06-23',
	);


	/**
	 * Save and return
	 */
	$dictionary = array(

		'Save & return' => 'Enregistrer et retour',
		
		'Save & new' => 'Enregistrer et nouveau',
	
	);
