<?php

	$about = array(
		'name' => 'Nederlands',
		'author' => array(
			'name' => 'Carsten de Vries',
			'email' => 'carsten@vrieswerk.nl',
			'website' => 'http://www.vrieswerk.nl'
		),
		'release-date' => '2009-11-09'
	);

	
	/*
	 * EXTENSION: Field: Select Box Link
	 * Localisation strings
	 */

	$dictionary = array(

		'Select Box Link' => 
		'Selectiebox-link',
		
		'None' =>
		false,

		'Options' => 
		'Opties',

		'Limit to the %s most recent entries' => 
		'Limiteer tot de %s meest recente items',

		'Allow selection of multiple options' => 
		'Sta selectie van meerdere opties toe'

	);	
	