<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Igor Bogdanov',
			'email' => 'i.bogdanov@ibcico.com',
			'website' => false
		),
		'release-date' => '2009-11-27'
	);
	
	
	/*
	 * EXTENSION: Field: Select Box Link
	 * Localisation strings
	 */

	$dictionary = array(
	
		'Select Box Link' => 
		'Ссылка на сущность',
		
		'None' =>
		false,

		'Options' => 
		'Опции',

		'Limit to the %s most recent entries' => 
		'Ограничение на %s последних записей.',

		'Allow selection of multiple options' => 
		'Разрешить выбор нескольких опций.'

	);
	