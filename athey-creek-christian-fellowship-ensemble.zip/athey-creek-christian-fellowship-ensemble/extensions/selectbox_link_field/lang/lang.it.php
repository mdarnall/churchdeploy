<?php

	$about = array(
		'name' => 'Italiano',
		'author' => array(
			'name' => 'Simone Economo',
			'email' => 'my.ekoes@gmail.com',
			'website' => 'http://lineheight.net',
		),
		'release-date' => '2010-02-25',
	);


	/**
	 * Field: Select Box Link
	 */
	$dictionary = array(

		'Select Box Link' => 
		'Giunzione fra sezioni',

		'None' => 
		'Nessuno',

		'Options' => 
		'Fonti',

		'Limit to the %s most recent entries' => 
		'Limita alle %s voci più recenti',

		'Allow selection of multiple options' => 
		'Consenti la selezione di pi&ugrave; elementi',

	);
