<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => 'http://www.nilshoerrmann.de'
		),
		'release-date' => '2009-12-29'
	);
	
	
	/*
	 * EXTENSION: Debug Devkit
	 * Localisation strings
	 */

	$dictionary = array(

		'Debug' => 
		'Debug',

		'Params' => 
		'Parameter',

		'XML' => 
		'XML',

		'Result' => 
		'Ergebnis'	

	);
	