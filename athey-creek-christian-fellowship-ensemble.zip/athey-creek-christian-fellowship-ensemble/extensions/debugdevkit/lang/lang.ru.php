<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Igor Bogdanov',
			'email' => 'i.bogdanov@ibcico.com',
			'website' => false
		),
		'release-date' => '2009-11-27'
	);
	
	
	/*
	 * EXTENSION: Debug Devkit
	 * Localisation strings
	 */

	$dictionary = array(
	
		'Debug' => 
		'Отладка',

		'Params' => 
		'Параметры',

		'XML' => 
		'XML',

		'Result' => 
		'Результат'
		
	);
	