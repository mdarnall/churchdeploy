<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad_micutul@yahoo.com',
		),
		'release-date' => '2011-02-11'
	);

	/**
	 * Configuration Settings
	 */
	$dictionary = array(

		'Configuration' => 
		'Configurare',

		'Site Name' => 
		'Nume Site',

		'Edit Settings' => 
		'Editează Setările',

		'Save Settings' => 
		'Salvează Setările',
	
		'Configuration Settings updated successfully.' => 
		'Setările de Configurare au fost salvate cu succes.',

		'An error occurred.' => 
		'A intervenit o eroare.',

	);
