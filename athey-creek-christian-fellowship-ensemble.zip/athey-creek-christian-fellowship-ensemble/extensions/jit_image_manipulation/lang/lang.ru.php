<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Igor Bogdanov',
			'email' => 'i.bogdanov@ibcico.com',
			'website' => false
		),
		'release-date' => '2009-11-27'
	);
	
	
	/*
	 * EXTENSION: JIT Image Manipulation
	 * Localisation strings
	 */

	$dictionary = array(

		'JIT Image Manipulation' => 
		'Обрабатывание изображений JIT',

		'Trusted Sites' => 
		'Доверенные сайты',

		'Leave empty to disable external linking. Single rule per line. Add * at end for wild card matching.' => 
		'Оставьте поле пустым, чтобы запретить внешние ссылки. Только одно правило в строке. Используйте * для замены любого символа.'

	);