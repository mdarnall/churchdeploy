<?php

	$about = array(
		'name' => 'Italiano',
		'author' => array(
			'name' => 'Simone Economo',
			'email' => 'my.ekoes@gmail.com',
			'website' => 'http://lineheight.net',
		),
		'release-date' => '2010-02-25',
	);


	/**
	 * JIT Image Manipulation
	 */
	$dictionary = array(

		'JIT Image Manipulation' => 
		'JIT Manipolazione delle immagini "al volo"',

		'Trusted Sites' => 
		'Siti fidati',

		'Leave empty to disable external linking. Single rule per line. Add * at end for wild card matching.' => 
		'Lascia vuoto questo campo se vuoi rendere visibili le immagini solo sul tuo sito. Per ogni riga va un solo indirizzo. Il carattere "*" sta per "ogni".',

	);
