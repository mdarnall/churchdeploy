<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad.ghita@xandergroup.ro',
			'website' => ''
		),
		'release-date' => '2011-04-01'
	);

	/**
	 * Publish Filtering
	 */
	$dictionary = array(

		'Disable publish filtering for this section' => 
		'Afişează filtrarea înregistrărilor pentru această secţiune.',

		'contains' => 
		'conţine',

		'is' => 
		'este',

		'Filter' => 
		'Filtrează',

		'Clear filters' => 
		'Şterge filtrele',

		'entry' => 
		'înregistrare',

		'entries' => 
		'înregistrări',

	);
