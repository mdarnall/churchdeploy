<?php

	$about = array(
		'name' => 'Italiano',
		'author' => array(
			'name' => 'Simone Economo',
			'email' => 'my.ekoes@gmail.com',
			'website' => 'http://lineheight.net',
		),
		'release-date' => '2010-08-24',
	);
	
	
	/*
	 * EXTENSION: Publish Filtering
	 * Localisation strings
	 */

	$dictionary = array(
	
		'Clear' =>
		'Azzera',
		
		'contains' =>
		'contiene',
		
		'is' =>
		'&egrave;',
		
		'entry' =>
		'voce',
		
		'entries' =>
		'voci'

	);
